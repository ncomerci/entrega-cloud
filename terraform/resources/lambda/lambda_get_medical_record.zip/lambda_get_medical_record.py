def getMedicalRecord(): 

    print("Aca hay que mostrar un medical record")